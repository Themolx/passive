const theme = {
  colors: {
    primary: '#6366f1',    // Indigo
    secondary: '#ec4899',  // Pink
    accent: '#8b5cf6',    // Purple
    dark: '#1f2937',      // Gray-800
    light: '#f3f4f6',     // Gray-100
  }
}; 