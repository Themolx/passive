export const aeCustomPanelPost = {
    slug: 'ae-custom-panel',
    title: "Creating a Custom Panel for After Effects: Streamlining Your Workflow",
    date: "March 29, 2024",
    author: "Martin Tomek",
    tags: ["After Effects", "Automation", "VFX", "Workflow", "Discord"],
    content: [
      {
        type: 'personal-intro',
        content: "Welcome to my latest blog post where I delve into the process of creating a custom panel for After Effects. This tool has significantly streamlined my workflow, automating repetitive tasks and enhancing productivity."
      },
      {
        type: 'journey-start',
        content: {
          title: "The Need for a Custom Panel 🛠️",
          text: "In the dynamic world of VFX and motion design, efficiency is paramount. I found myself frequently performing repetitive tasks that not only consumed time but also left room for errors. This led me to the idea of creating a custom panel for After Effects to automate these processes."
        }
      },
      {
        type: 'development-timeline',
        content: {
          title: "Development Milestones 🚀",
          stages: [
            {
              date: "January 10, 2024",
              title: "Idea Conception",
              description: `
I identified the need for a tool that could:
• Track week numbers for consistent deliverables
• Automate exporting files with standardized naming conventions
• Integrate with communication platforms to send notifications
`
            },
            {
              date: "January 20, 2024",
              title: "Tool Setup",
              description: `
I started by setting up my development environment using **Cursor IDE**, which offers real-time collaboration and intelligent code completion, making it ideal for efficient coding.
`
            },
            {
              date: "February 5, 2024",
              title: "Initial Development",
              description: `
Leveraging **EEAct**, a React-based framework for After Effects scripting, I began building the user interface of the custom panel. **Claude AI** assisted me by suggesting code snippets and optimizing my scripts.
`
            },
            {
              date: "February 25, 2024",
              title: "Feature Implementation",
              description: `
Implemented key features:
• **Week Number Tracking**: Utilized JavaScript's Date object to calculate and remember the current week number based on ISO standards.
• **Automated Exporting**: Scripted After Effects to export files in predefined formats with standardized naming conventions.
• **Discord Integration**: Connected to a Discord bot to send custom messages, automating team notifications.
`
            },
            {
              date: "March 15, 2024",
              title: "Testing & Optimization",
              description: `
Thorough testing was conducted to ensure:
• Accurate week number tracking
• Reliable file exporting without errors
• Robust Discord integration with error handling mechanisms
`
            },
            {
              date: "March 29, 2024",
              title: "Release",
              description: `
The custom panel was deployed, significantly enhancing workflow efficiency by automating critical tasks and fostering better team communication.
`
            }
          ]
        }
      },
      {
        type: 'section',
        content: [
          {
            title: "Tools and Technologies Used 🔧",
            description: "Creating the custom panel involved several key tools and technologies:",
            code: "### Tools and Technologies\n\n**Claude AI**: An advanced AI assistant that aids in coding by providing intelligent suggestions, debugging help, and code optimization.\n\n**Cursor IDE**: A robust IDE designed for modern web development, offering features like real-time collaboration and intelligent code completion.\n\n**EEAct**: A specialized framework that integrates React with After Effects, allowing developers to build custom panels using React's declarative UI."
          }
        ]
      },
      {
        type: 'personal-intro',
        content: "Throughout the development process, I encountered several challenges and learning opportunities that not only improved the tool but also enhanced my skills as a technical director."
      },
      {
        type: 'journey-start',
        content: {
          title: "Key Features of the Custom Panel 🌟",
          text: "The custom panel is designed to automate and streamline multiple aspects of the After Effects workflow. Here are the standout features:"
        }
      },
      {
        type: 'development-timeline',
        content: {
          title: "Feature Breakdown 📦",
          stages: [
            {
              date: "Week Number Tracking",
              title: "Consistency in Deliverables",
              description: `
Using JavaScript's Date object, the panel calculates the current week number based on ISO standards. This ensures that all deliverables are consistently labeled and tracked according to our production schedule.

\`\`\`javascript
const getWeekNumber = () => {
  const date = new Date();
  const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
  const pastDaysOfYear = (date - firstDayOfYear) / 86400000;
  return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
};
\`\`\`
`
            },
            {
              date: "Automated Exporting",
              title: "Efficient File Management",
              description: `
Automating the export process involves scripting After Effects to export files in pre-defined formats with standardized naming conventions. This reduces manual errors and saves valuable time.

\`\`\`javascript
const exportFile = (composition, format, weekNumber) => {
  const exportSettings = { format };
  const exportName = \`Project_Week_\${weekNumber}_\${composition.name}\`;
  // After Effects export logic
};
\`\`\`
`
            },
            {
              date: "Discord Integration",
              title: "Seamless Team Communication",
              description: `
Integrating with a Discord bot allows the custom panel to send automated messages to a specific channel, notifying team members about new exports or updates. This eliminates the need for repetitive manual notifications.

\`\`\`javascript
const sendDiscordMessage = (message) => {
  fetch('https://discord.com/api/webhooks/your-webhook-url', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content: message }),
  });
};
\`\`\`
`
            }
          ]
        }
      },
      {
        type: 'interactive-demo',
        content: {
          title: "Try These Interactive Demos! 🎮",
          demos: [
            {
              title: "Blob Animation Demo",
              component: "BlobDemo",
              description: "Experiment with different blob animations and interactions."
            },
            {
              title: "Drag Interaction Demo",
              component: "DragDemo",
              description: "Test various dragging behaviors and constraints."
            },
            {
              title: "Advanced Examples",
              component: "Example",
              description: "Explore more complex animations and interactions."
            }
          ]
        }
      },
      {
        type: 'technical-breakdown',
        content: {
          title: "Under the Hood 🛠️",
          text: "The custom panel leverages several advanced technologies and best practices to deliver a seamless user experience:",
          features: [
            {
              title: "React Integration",
              description: "Leveraging React's declarative UI paradigm through EEAct for building a responsive and interactive interface.",
              icon: "⚛️"
            },
            {
              title: "Automation Scripts",
              description: "Custom scripts that handle file exporting, naming conventions, and week number tracking to automate repetitive tasks.",
              icon: "🤖"
            },
            {
              title: "Robust Communication",
              description: "Integration with Discord allows for automated team notifications, enhancing communication efficiency.",
              icon: "💬"
            }
          ]
        }
      },
      {
        type: 'conclusion',
        content: {
          title: "The Impact on Workflow ✨",
          sections: [
            {
              text: "The custom panel has transformed my workflow by automating critical tasks, ensuring consistency in deliverables, and enhancing team communication. What was once a time-consuming manual process is now seamlessly integrated into my After Effects environment.",
              type: "reflection"
            },
            {
              text: "Find the custom panel on GitHub:",
              links: [
                {
                  text: "View AeCustomPanel on GitHub",
                  url: "https://github.com/Themolx/AeCustomPanel",
                  primary: true
                }
              ],
              type: "cta"
            },
            {
              text: "Remember: Automation is key to efficiency in VFX production. Explore how you can streamline your workflow and focus more on creativity by automating repetitive tasks. 🚀",
              type: "inspiration"
            }
          ]
        }
      }
    ]
};
  