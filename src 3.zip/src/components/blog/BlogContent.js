import React from 'react';
import { motion } from 'framer-motion';
import { BlobDemo } from '../demos/BlobDemo';
import { DragDemo } from '../demos/DragDemo';
import { Example } from '../demos/Example';

function BlogContent({ content }) {
  switch (content.type) {
    case 'personal-intro':
      return (
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-xl text-gray-300 leading-relaxed mb-12"
        >
          {content.content}
        </motion.p>
      );

    case 'journey-start':
      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-bold mb-4">{content.content.title}</h2>
          <p className="text-gray-300 leading-relaxed">{content.content.text}</p>
        </motion.div>
      );

    case 'development-timeline':
      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-bold mb-8">{content.content.title}</h2>
          <div className="space-y-8">
            {content.content.stages.map((stage, index) => (
              <div key={index} className="relative pl-8 border-l border-purple-500/30">
                <div className="absolute left-0 top-0 w-3 h-3 -translate-x-[7px] rounded-full bg-purple-500" />
                <span className="text-sm text-purple-400">{stage.date}</span>
                <h3 className="text-lg font-semibold mt-1 mb-2">{stage.title}</h3>
                <div className="prose prose-invert max-w-none">
                  {stage.description}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      );

    case 'section':
      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          {content.content.map((section, index) => (
            <div key={index}>
              <h2 className="text-2xl font-bold mb-4">{section.title}</h2>
              <p className="text-gray-300 mb-6">{section.description}</p>
              <div className="prose prose-invert max-w-none">
                {section.code}
              </div>
            </div>
          ))}
        </motion.div>
      );

    case 'interactive-demo':
      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12 space-y-12"
        >
          <h2 className="text-2xl font-bold mb-6">{content.content.title}</h2>
          
          {content.content.demos?.map((demo, index) => (
            <div key={index} className="bg-black/30 rounded-lg p-8">
              <h3 className="text-xl font-semibold mb-4">{demo.title}</h3>
              <p className="text-gray-300 mb-6">{demo.description}</p>
              
              <div className="rounded-lg overflow-hidden">
                {demo.component === "BlobDemo" && <BlobDemo />}
                {demo.component === "DragDemo" && <DragDemo />}
                {demo.component === "Example" && <Example />}
              </div>
            </div>
          ))}
        </motion.div>
      );

    case 'technical-breakdown':
      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-bold mb-6">{content.content.title}</h2>
          <p className="text-gray-300 mb-8">{content.content.text}</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {content.content.features.map((feature, index) => (
              <div key={index} className="bg-black/30 rounded-lg p-6">
                <div className="text-3xl mb-4">{feature.icon}</div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-300">{feature.description}</p>
              </div>
            ))}
          </div>
        </motion.div>
      );

    case 'conclusion':
      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-12 border-t border-white/10 pt-12"
        >
          <h2 className="text-2xl font-bold mb-8">{content.content.title}</h2>
          
          {content.content.sections.map((section, index) => (
            <div key={index} className="mb-8">
              {section.type === "reflection" && (
                <p className="text-xl text-gray-300 leading-relaxed mb-6">
                  {section.text}
                </p>
              )}
              
              {section.type === "cta" && (
                <div className="bg-white/5 rounded-lg p-6 mb-8">
                  <p className="text-gray-300 mb-4">{section.text}</p>
                  <div className="flex flex-wrap gap-4">
                    {section.links.map((link, i) => (
                      <a
                        key={i}
                        href={link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`px-6 py-3 rounded-lg transition-colors ${
                          link.primary 
                            ? 'bg-purple-600 hover:bg-purple-700' 
                            : 'bg-white/10 hover:bg-white/20'
                        }`}
                      >
                        {link.text}
                      </a>
                    ))}
                  </div>
                </div>
              )}
              
              {section.type === "inspiration" && (
                <p className="text-lg text-gray-300 italic">
                  {section.text}
                </p>
              )}
            </div>
          ))}
        </motion.div>
      );

    default:
      return null;
  }
}

export default BlogContent;